import type {Metadata} from "next";
export const metadata:Metadata={title:"Business Letter Unit 1 · Attendance",description:"Attendance service for the business letter course",icons:{icon:"/favicon.svg"}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body style={{margin:0,background:"#f2f5fa"}}>{children}</body></html>}
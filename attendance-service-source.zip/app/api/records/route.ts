import {db,response,teacherAuthorized,taipeiDay} from "@/lib/attendance";
export const dynamic="force-dynamic";
export function OPTIONS(){return response({},200)}
export async function GET(request:Request){try{
if(!await teacherAuthorized(request))return response({error:"Incorrect teacher access key."},401);
const day=new URL(request.url).searchParams.get("date")||taipeiDay();
if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||Number.isNaN(Date.parse(day))||new Date(day).toISOString().slice(0,10)!==day)return response({error:"Invalid date"},400);
const result=await db().prepare("SELECT student_id AS studentId,timestamp FROM checkins WHERE day=? ORDER BY timestamp,student_id").bind(day).all();
return response({records:result.results});
}catch{return response({error:"Attendance records are temporarily unavailable."},503)}}

import {db,response,taipeiDay} from "@/lib/attendance";
export const dynamic="force-dynamic";
export function OPTIONS(){return response({},200)}
export async function POST(request:Request){try{
if(request.headers.get("origin")!=="https://ij-teacher.github.io")return response({error:"Request origin not allowed"},403);
if(!request.headers.get("content-type")?.includes("application/json"))return response({error:"JSON required"},415);
if(Number(request.headers.get("content-length")||0)>512)return response({error:"Request too large"},413);
const raw=await request.text();if(raw.length>512)return response({error:"Request too large"},413);
let body;try{body=JSON.parse(raw)}catch{return response({error:"Invalid request"},400)}
if(typeof body.studentId!=="string")return response({error:"Student ID required"},400);
const studentId=body.studentId.trim().toUpperCase();
if(!/^[A-Z0-9][A-Z0-9-]{3,19}$/.test(studentId))return response({error:"Use 4–20 letters, numbers or hyphens, starting with a letter or number."},400);
const day=taipeiDay(),timestamp=new Date().toISOString(),id=crypto.randomUUID();
const result=await db().prepare("INSERT INTO checkins (id,student_id,day,timestamp) VALUES (?,?,?,?) ON CONFLICT(day,student_id) DO NOTHING").bind(id,studentId,day,timestamp).run();
const record=await db().prepare("SELECT timestamp FROM checkins WHERE day=? AND student_id=?").bind(day,studentId).first<{timestamp:string}>();
if(!record)throw Error("Check-in was not persisted");
return response({ok:true,duplicate:result.meta.changes===0,timestamp:record.timestamp});
}catch(error){console.error("Attendance save failed");return response({error:"Check-in could not be saved. Please try again."},503)}}

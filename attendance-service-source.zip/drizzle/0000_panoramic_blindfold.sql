CREATE TABLE `checkins` (
	`id` text PRIMARY KEY NOT NULL,
	`student_id` text NOT NULL,
	`day` text NOT NULL,
	`timestamp` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `checkins_day_student` ON `checkins` (`day`,`student_id`);